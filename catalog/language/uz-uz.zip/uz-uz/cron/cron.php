<?php
// Matn
$_['text_success']     = '%s vazifasini muvaffaqiyatli bajardingiz!';

// Xato
$_['error_permission'] = 'Diqqat: Sizning vazifalarni boshqarishga ruxsat yo\'q!';
