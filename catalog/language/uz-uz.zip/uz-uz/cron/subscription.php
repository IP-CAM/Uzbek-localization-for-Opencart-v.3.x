<?php
// Matn
$_['text_success']     = 'Muvaffaqiyat: Obuna profili muvaffaqiyatli yangilandi!';

// Xato
$_['error_extension']  = 'Diqqat: To\'lov usuli kengaytmasi topilmadi!';
$_['error_recurring']  = 'Diqqat: To\'lov usuli takroriy to\'lovni qo\'llamaydi!';
$_['error_payment']    = 'Diqqat: To\'lov usuli %s topilmadi!';
