<?php
// Sarlavha
$_['heading_title']     = 'Aksiya';

// Matn
$_['text_no_results']   = 'Aksiya bo\'yicha hech qanday mahsulot yo\'q.';
$_['text_compare']      = 'Mahsulotlar bilan solishtirish (%s)';
$_['text_sort']         = 'Saralash:';
$_['text_default']      = 'Standart';
$_['text_name_asc']     = 'Nomi (A - Z)';
$_['text_name_desc']    = 'Nomi (Z - A)';
$_['text_price_asc']    = 'Narxi (arzon &gt; qimmat)';
$_['text_price_desc']   = 'Narxi (qimmat &gt; arzon)';
$_['text_rating_asc']   = 'Reyting (pastdan boshlab)';
$_['text_rating_desc']  = 'Reyting (ustundan boshlab)';
$_['text_model_asc']    = 'Model (A - Z)';
$_['text_model_desc']   = 'Model (Z - A)';
$_['text_limit']        = 'Ko\'rsatish:';
