<?php
// Matn
$_['text_refine']       = 'Tovarlar turini tanlang';
$_['text_product']      = 'Tovarlar';
$_['text_error']        = 'Kategoriya topilmadi!';
$_['text_no_results']   = 'Ushbu kategoriyada tovarlar mavjud emas.';
$_['text_compare']      = 'Taqqoslash (%s)';
$_['text_sort']         = 'Tartiblash:';
$_['text_default']      = 'Standart';
$_['text_name_asc']     = 'Nomi (A - Y)';
$_['text_name_desc']    = 'Nomi (Y - A)';
$_['text_price_asc']    = 'Narxi (past &gt; yuqori)';
$_['text_price_desc']   = 'Narxi (yuqori &gt; past)';
$_['text_rating_asc']   = 'Reyting (pastdan boshlab)';
$_['text_rating_desc']  = 'Reyting (yuqoridan pastga)';
$_['text_model_asc']    = 'Model (A - Y)';
$_['text_model_desc']   = 'Model (Y - A)';
$_['text_limit']        = 'Ko‘rsatish:';
