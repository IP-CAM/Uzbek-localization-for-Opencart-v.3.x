<?php
// Matn
$_['text_price'] = 'Narx:';
$_['text_tax']   = 'QQSsiz:';
