<?php
// Matn
$_['text_upload']     = 'Fayl muvaffaqiyatli yuklandi!';

// Xatolik
$_['error_filename']  = 'Fayl nomi 3 ila 64 belgidan iborat bo\'lishi kerak!';
$_['error_file_type'] = 'Noto\'g\'ri fayl turi!';
$_['error_upload']    = 'Faylni yuklash kerak!';
