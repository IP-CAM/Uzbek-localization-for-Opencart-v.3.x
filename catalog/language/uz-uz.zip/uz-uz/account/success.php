<?php
// Sarlavha
$_['heading_title'] = 'Sizning hisobingiz yaratildi!';

// Matn
$_['text_success']  = '<p>Ta`briklaymiz! Sizning Shaxsiy Kabinetingiz muvaffaqiyatli yaratildi.</p><p>Endi siz qo`shimcha imkoniyatlardan foydalana olasiz: buyurtmalar tarixini ko`rish, hisobotni chop etish, aloqa ma`lumotlarini va yetkazib berish manzillarini o`zgartirish va boshqalarini ko`rish.</p><p>Agar savollaringiz bo`lsa,  <a href="%s">bizga yozing</a>.</p>';
$_['text_approval'] = '<p>%s ro`yxatdan o`tganingiz uchun rahmat!</p><p>Sizga Shaxsiy Kabinetingiz ma`murlar tomonidan faollashtirilganda, elektron pochta orqali xabar beriladi.</p><p>Agar savol yoki takliflaringiz bo`lsa, iltimos, <a href="%s">bizga yozing</a>.</p>';
$_['text_account']  = 'Shaxsiy Kabinet';
