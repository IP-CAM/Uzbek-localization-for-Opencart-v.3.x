<?php
// Sarlavha
$_['heading_title']         = 'To\'lov usullari';

// Matn
$_['text_account']          = 'Hisob-kitob';
$_['text_payment_method']   = 'To\'lov usullari';
$_['text_success']          = 'Sizning to\'lov usulingiz muvaffaqiyatli o\'chirildi';
$_['text_no_results']       = 'Hisobingizda to\'lov usullari yo\'q.';

// Ustunlar
$_['column_payment_method'] = 'To\'lov usuli';
$_['column_type']           = 'Turi';
$_['column_date_expire']    = 'Amal qilish muddati';
$_['column_action']         = 'Harakat';

// Xatolik
$_['error_payment_method']  = 'Ogohlantirish: To\'lov usulini topolmayapti!';
