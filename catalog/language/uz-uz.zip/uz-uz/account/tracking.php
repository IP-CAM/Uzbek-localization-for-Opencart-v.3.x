<?php
// Sarlavha
$_['heading_title']    = 'Hamkor Referrallari';

// Matn
$_['text_account']     = 'Hamkor Kabinet';
$_['text_description'] = 'Hamkorlik dasturidan foydalanish uchun, siz bizning saytga o`tkazib beradigan referral havolani joylashishingiz kerak. Quyidagi usuldan foydalanib, %s uchun referral havolalarni yarating.';

// Kiritma
$_['entry_code']       = 'Sizning Referral kodingiz';
$_['entry_generator']  = 'Referral havolani yaratish';
$_['entry_link']       = 'Referral havola';

// Yordam
$_['help_generator']   = 'Referral havola yaratmoqchi bo`lgan mahsulotning nomini kiriting.';
