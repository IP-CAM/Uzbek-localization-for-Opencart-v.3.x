<?php
// Sarlavha
$_['heading_title']      = 'Tranzaksiya Tarixi';

// Ustun
$_['column_date_added']  = 'Qo`shilgan sana';
$_['column_description'] = 'Tavsif';
$_['column_amount']      = 'Summa (%s)';

// Matn
$_['text_account']       = 'Shaxsiy Kabinet';
$_['text_transaction']   = 'Sizning tranzaksiyalaringiz';
$_['text_total']         = 'Joriy balansingiz';
$_['text_no_results']    = 'Sizda tranzaksiya yo`q!';
