<?php
// Sarlavha
$_['heading_title']  = 'Parolni o\'zgartirish';

// Matn
$_['text_account']   = 'Shaxsiy Kabinet';
$_['text_password']  = 'Sizning parolingiz';
$_['text_success']   = 'Sizning parolingiz muvaffaqiyatli o\'zgartirildi!';

// Kiritmalar
$_['entry_password'] = 'Parol';
$_['entry_confirm']  = 'Parolni tasdiqlang';

// Xatolik
$_['error_token']    = 'Diqqat: Noto\'g\'ri parol tokeni!';
$_['error_password'] = 'Parol 4 dan 20 gacha belgidan iborat bo\'lishi kerak!';
$_['error_confirm']  = 'Parol va tasdiqlash paroli bir xil bo\'lishi kerak!';
