<?php
// Sarlavha
$_['heading_title'] = 'Chiqish';

// Matn
$_['text_message']  = '<p>Siz Shaxsiy Kabinetdan chiqdingiz.</p><p>Sizning xarid savatingiz saqlandi. Ushbu Shaxsiy Kabinetga keyingi kirishda tiklanadi.</p>';
$_['text_account']  = 'Shaxsiy Kabinet';
$_['text_logout']   = 'Chiqish';
