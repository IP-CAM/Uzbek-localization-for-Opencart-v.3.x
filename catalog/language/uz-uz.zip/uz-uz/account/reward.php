<?php
// Sarlavha
$_['heading_title']      = 'Bonus ballar';

// Qator
$_['column_date_added']  = 'Qo\'shilgan sana';
$_['column_description'] = 'Tavsif';
$_['column_points']      = 'Bonus ballar';

// Matn
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_reward']        = 'Bonus ballar';
$_['text_total']         = 'Jami bonus ballar';
$_['text_no_results']    = 'Sizda bonus ballar yo\'q!';
