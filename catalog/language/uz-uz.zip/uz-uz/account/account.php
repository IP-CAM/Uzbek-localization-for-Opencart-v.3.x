<?php
// Sarlavha
$_['heading_title']       = 'Shaxsiy Kabinet';

// Matn
$_['text_account']        = 'Shaxsiy Kabinet';
$_['text_my_account']     = 'Mening hisobim';
$_['text_my_orders']      = 'Mening buyurtmalarim';
$_['text_my_affiliate']   = 'Mening partnyor hisobim';
$_['text_my_newsletter']  = 'Obuna';
$_['text_edit']           = 'Kontakt ma\'lumotlarini o\'zgartirish';
$_['text_password']       = 'Parolingizni o\'zgartirish';
$_['text_address']        = 'Mening manzillarimni o\'zgartirish';
$_['text_payment_method'] = 'To\'lov usullari';
$_['text_wishlist']       = 'Xaridlarimni ko\'rish';
$_['text_order']          = 'Buyurtmalar tarixi';
$_['text_subscription']   = 'Obunalar';
$_['text_download']       = 'Yuklab olish uchun fayllar';
$_['text_reward']         = 'Mukofot bollari';
$_['text_return']         = 'Qaytarish so\'rovlari';
$_['text_transaction']    = 'Tranzaksiyalar tarixi';
$_['text_newsletter']     = 'Yangiliklar ro\'yxatiga obuna bo\'lish yoki obunani bekor qilish';
$_['text_transactions']   = 'Tranzaksiyalar';
$_['text_affiliate_add']  = 'Partnyor hisobini ro\'yxatdan o\'tish';
$_['text_affiliate_edit'] = 'Partnyor ma\'lumotlarini o\'zgartirish';
$_['text_tracking']       = 'Partnyorlik uchrashuvlarini kuzatish kodi';
