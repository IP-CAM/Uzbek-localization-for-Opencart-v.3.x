<?php
// Sarlavha
$_['heading_title']    = 'Yangiliklar uchun obuna bo\'lish';

// Matn
$_['text_account']     = 'Shaxsiy Kabinet';
$_['text_newsletter']  = 'Xabarlar';
$_['text_success']     = 'Sizning obuna tizimi muvaffaqiyatli yangilandi!';

// Kiritish
$_['entry_newsletter'] = 'Obuna bo\'lish';
