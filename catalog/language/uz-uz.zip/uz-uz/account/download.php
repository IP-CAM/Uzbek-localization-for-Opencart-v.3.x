<?php
// Sarlavha
$_['heading_title']      = 'Yuklanish uchun fayllar';

// Matn
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_downloads']     = 'Yuklanish uchun fayllar';
$_['text_no_results']    = 'Sizda yuklab olish uchun fayllar bor emas!';

// Ustun
$_['column_order_id']    = 'Buyurtma №';
$_['column_name']        = 'Nomi';
$_['column_size']        = 'Hajmi';
$_['column_date_added']  = 'Qo\'shilgan sana';

// Xatolik
$_['error_not_found']    = 'Xatolik: Fayl %s topilmadi!';
$_['error_headers_sent'] = 'Xatolik: Sarlavhalarni jo\'natish tayyor!';
