<?php
// Matn
$_['text_subject']  = '%s - Yangi parol';
$_['text_greeting'] = '%s saytidagi yangi parol so‘roq qilindi.';
$_['text_change']   = 'Parolni tiklash uchun quyidagi havolaga o‘ting:';
$_['text_ip']       = 'Bu IP manzilidan yangi parol so‘roqlanmoqda:';

// Tugma
$_['button_reset']  = 'Parolni tiklash';
