<?php
// Matn
$_['text_subject']              = '%s - Buyurtma %s - Obuna bekor qilindi';
$_['text_received']             = 'Siz obuna bekor qilindi xabarini oldingiz.';
$_['text_orders_id']            = 'Buyurtma raqami:';
$_['text_subscription_id']      = 'Obuna raqami';
$_['text_date_added']           = 'Qo‘shilgan sana:';
$_['text_subscription_status']  = 'Obuna holati:';
$_['text_comment']              = 'Sizning obuna uchun izohlar:';
$_['text_canceled']             = 'Muvaffaqiyatli: Obuna profilini bekor qilindi!';
