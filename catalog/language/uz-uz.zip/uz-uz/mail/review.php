<?php
// Matn
$_['text_subject']  = '%s - Mahsulot sharhi';
$_['text_waiting']  = 'Yangi sharhlar tekshirishni kutmoqda .';
$_['text_product']  = 'Mahsulot: %s';
$_['text_reviewer'] = 'Sharh qoldirgan: %s';
$_['text_rating']   = 'Baho: %s';
$_['text_review']   = 'Sharh:';
