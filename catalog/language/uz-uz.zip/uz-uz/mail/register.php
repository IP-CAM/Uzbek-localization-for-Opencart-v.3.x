<?php
// Matn
$_['text_subject']        = '%s - Ro‘yxatdan o‘tganingiz uchun rahmat';
$_['text_welcome']        = '%s ga xush kelibsiz va ro‘yxatdan o‘tganingiz uchun rahmat!!';
$_['text_login']          = 'Sizning akkauntingiz yaratilgan va Siz uni, quyidagi havoladan E-mail va parol orqali kirishingiz mumkin:';
$_['text_approval']       = 'Sizning akkauntingiz yaratilgan va tasdiqlashni kutmoqda. Tasdiqlanganidan so‘ng Siz do‘konga E-mail va parol orqali kirishingiz mumkin, quyidagi havoladan:';
$_['text_service']        = 'Tizimga kirgandan so‘ng, Siz oxirgi buyurtmalaringizni ko‘rish, fakturalarni chop etish va akkauntingiz ma‘lumotlarini tahrirlash kabi xizmatlarga kirishingiz mumkin.';
$_['text_thanks']         = 'Rahmat,';
$_['text_new_customer']   = 'Yangi mijoz';
$_['text_signup']         = 'Yangi mijoz ro‘yxatdan o‘tdi:';
$_['text_customer_group'] = 'Mijoz guruhu:';
$_['text_firstname']      = 'Ism, Sharif:';
$_['text_lastname']       = 'Familiya:';
$_['text_email']          = 'E-mail:';
$_['text_telephone']      = 'Telefon:';

// Tugma
$_['button_login']        = 'Kirish';
