<?php
// Matn
$_['text_subject']  = '%s - GDPR uchun eksport/o‘chirish so‘rovi!';
$_['text_export']   = 'Ma’lumotlarni eksport qilish so‘roqi';
$_['text_remove']   = 'Hisobni o‘chirish so‘roqi';
$_['text_gdpr']     = 'Bu elektron pochta manzilidan GDPR so‘rovi quyidagi harakatni tasdiqlash uchun jo‘natilgan, iltimos, quyidagi havolaga bosing:';
$_['text_ip']       = 'Ushbu so‘roqni yuborish uchun ishlatilgan IP-manzil:';
$_['text_contact']  = 'Agar siz bu so‘roqni yubormagan bo‘lsangiz, iltimos, do‘kon egasi bilan shu yerda bog‘laning:';
$_['text_thanks']   = 'Rahmat,';
$_['text_ignore']   = 'Agar siz bu so‘roqni yubormagan bo‘lsangiz, iltimos, ushbu xatni e’tiborsiz qoldiring.';

// Tugma
$_['button_export'] = 'Ma’lumotlarimni eksport qilishni tasdiqlayman';
$_['button_remove'] = 'Hisobni o‘chirishni tasdiqlayman';
