<?php
// Matn
$_['text_subject']      = '%s - Buyurtma %s';
$_['text_received']     = 'Siz buyurtma oldingiz.';
$_['text_order_id']     = 'Buyurtma raqami:';
$_['text_date_added']   = 'Buyurtma sanasi:';
$_['text_order_status'] = 'Buyurtma holati:';
$_['text_product']      = 'Mahsulotlar';
$_['text_total']        = 'Jami';
$_['text_comment']      = 'Buyurtmangiz uchun izoh:';
