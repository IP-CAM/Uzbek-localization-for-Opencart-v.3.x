<?php
// Matn
$_['text_subject']        = '%s - Hamkorlik dasturi';
$_['text_welcome']        = 'Tabriklaymiz. Siz %s do\'konimizning hamkorlari bo\'lg\'ansiz!';
$_['text_login']          = 'Sizning akkauntingiz yaratildi va Siz uni, quyidagi havoladan E-mail va parol orqali kirishingiz mumkin:';
$_['text_approval']       = 'Sizning hisobingiz tasdiqlanishi kutilmoqda. Tasdiqlanganidan so‘ng Siz do‘konimizning hamkor bo‘limiga quyidagi havoladan kirishingiz mumkin:';
$_['text_service']        = 'Tizimga kirgandan so‘ng, Siz kuzatuv kodi yaratishingiz, komissiyalarni kuzatishingiz va hisobingiz ma\'lumotlarini tahrirlashingiz mumkin bo‘ladi.';
$_['text_thanks']         = 'Rahmat,';
$_['text_new_affiliate']  = 'Yangi hamkor';
$_['text_signup']         = 'Yangi hamkor ro‘yxatdan o‘tdi:';
$_['text_website']        = 'Sayt:';
$_['text_customer_group'] = 'Guruh:';
$_['text_firstname']      = 'Ism, Sharif:';
$_['text_lastname']       = 'Familiya:';
$_['text_company']        = 'Kompaniya:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telefon:';

// Tugma
$_['button_login']        = 'Kirish';
