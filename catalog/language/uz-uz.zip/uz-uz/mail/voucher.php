<?php
// Matn
$_['text_subject']  = 'Siz %s sovrinini jo‘natdingiz';
$_['text_greeting'] = 'Tabriklaymiz, Siz %s dan sovrin oldingiz';
$_['text_from']     = 'Sizga %s sovrini jo‘natdi';
$_['text_message']  = 'Jo‘natuvchi sizga xabar qoldirdi';
$_['text_redeem']   = 'Ushbu sovrin bilan foydalanish uchun, <b>%s</b> kodi saqlang va keyin do‘konni tashrif buyurib, sizga yoqadigan mahsulotlarni buyurishingiz mumkin. Sovrin kodi kirishni boshlaganizdan oldin, buyurtmani rasmiylashtirish sahifasiga o‘ting.';
$_['text_footer']   = 'Agar sizda qandaydir savollar bo‘lsa, iltimos, ushbu xabarga javob bering.';
