<?php
// Matn
$_['text_subject']      = '%s - Buyurtma yangilandi %s';
$_['text_order_id']     = 'Buyurtma raqami:';
$_['text_date_added']   = 'Buyurtma sanasi:';
$_['text_order_status'] = 'Sizning buyurtmangiz quyidagi holatga yangilandi:';
$_['text_comment']      = 'Buyurtmangiz uchun izoh:';
$_['text_link']         = 'Buyurtmangizni ko‘rish uchun quyidagi havolaga o‘ting:';
$_['text_footer']       = 'Agar sizda savollar bo‘lsa, ushbu xabarga javob bering.';
