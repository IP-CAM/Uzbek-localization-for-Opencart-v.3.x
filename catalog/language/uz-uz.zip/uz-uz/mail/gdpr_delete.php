<?php
// Matn
$_['text_subject']   = '%s - SHOZD so‘rovi bajarildi!';
$_['text_request']   = 'Hisobni o‘chirish so‘roqi';
$_['text_hello']     = 'Salom <strong>%s</strong>,';
$_['text_user']      = 'foydalanuvchi';
$_['text_delete']    = 'Sizning SHOZD ma’lumotlarni o‘chirish so‘roqingiz bajarildi.';
$_['text_contact']   = 'Qo‘shimcha ma’lumot olish uchun do‘kon egasi bilan shu joyda bog‘lanishingiz mumkin:';
$_['text_thanks']    = 'Rahmat,';

// Tugma
$_['button_contact'] = 'Biz bilan bog‘laning';
