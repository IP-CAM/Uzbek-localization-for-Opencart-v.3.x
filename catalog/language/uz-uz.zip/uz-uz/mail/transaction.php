<?php
// Matn
$_['text_subject']  = '%s - Hamkorlik komissiyasi';
$_['text_received'] = 'Tabriklaymiz! Siz hamkorlik dasturiga %s miqdorida komissiya olishingiz mumkin';
$_['text_amount']   = 'Siz komissiya olgan summa:';
$_['text_total']    = 'Umumiy komissiya balansi:';
