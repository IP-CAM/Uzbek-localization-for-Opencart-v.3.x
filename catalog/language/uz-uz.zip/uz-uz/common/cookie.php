<?php
// Matn
$_['text_success'] = 'Tanlovlariz haqida xabar beringiz uchun rahmat!';
$_['text_cookie']  = 'Biz saytning ishlanishini yaxshilash uchun cookie fayllardan foydalanamiz. Saytda davom etish, ularni qo\'llashga rozilik berish hisoblanadi. <a href="%s" class="alert-link modal-link">Ko\'proq ma\'lumot</a>.';

// Tugma
$_['button_agree']    = 'Ha, bu ajoyib!';
$_['button_disagree'] = 'Yo\'q, rahmat!';
