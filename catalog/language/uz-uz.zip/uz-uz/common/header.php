<?php
// Matn
$_['text_wishlist']      = 'Sevimlilarm (%s)';
$_['text_shopping_cart'] = 'Savat';
$_['text_account']       = 'Shaxsiy kabinet';
$_['text_register']      = 'Ro\'yxatdan o\'tish';
$_['text_login']         = 'Kirish';
$_['text_order']         = 'Buyurtmalar tarixi';
$_['text_transaction']   = 'Tranzaksiyalar';
$_['text_download']      = 'Yuklamalar';
$_['text_logout']        = 'Chiqish';
$_['text_checkout']      = 'Buyurtma berish';
