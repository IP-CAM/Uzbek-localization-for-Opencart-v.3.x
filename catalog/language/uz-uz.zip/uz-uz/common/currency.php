<?php
// Matn
$_['text_currency'] = 'Valyuta';
