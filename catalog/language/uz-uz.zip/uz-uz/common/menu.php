<?php
// Matn
$_['text_category']  = 'Kategoriyalar';
$_['text_all']       = 'Hammasini ko\'rsatish';
