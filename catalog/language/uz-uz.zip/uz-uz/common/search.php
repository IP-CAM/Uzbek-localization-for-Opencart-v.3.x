<?php
// Matn
$_['text_search'] = 'Qidirish';
