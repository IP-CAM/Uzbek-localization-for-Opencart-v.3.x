<?php
// Matn
$_['text_information']  = 'Ma\'lumotlar';
$_['text_service']      = 'Xizmat ko\'rsatish';
$_['text_extra']        = 'Qo\'shimcha';
$_['text_contact']      = 'Bog\'lanish';
$_['text_return']       = 'Maxsulot qaytarish';
$_['text_sitemap']      = 'Sayt xaritasi';
$_['text_gdpr']         = 'Shaxsiy ma\'lumotlarni himoyalash';
$_['text_manufacturer'] = 'Ishlab chiqaruvchilar';
$_['text_voucher']      = 'Sovi bayrami';
$_['text_affiliate']    = 'Hamkorlik dasturi';
$_['text_special']      = 'Aksiyalar';
$_['text_account']      = 'Shaxsiy kabinet';
$_['text_order']        = 'Buyurtmalar tarixi';
$_['text_wishlist']     = 'Tanlanganlar';
$_['text_newsletter']   = 'Yangiliklar xabarlarini olish';
$_['text_powered']      = '<a href="https://azizmurod.uz">OpenCart "O\'zbek tahrirati"</a><br /> %s &copy; %s';
