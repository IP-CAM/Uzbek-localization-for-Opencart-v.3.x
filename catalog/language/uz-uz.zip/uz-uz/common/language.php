<?php
// Matn
$_['text_language'] = 'Til';
