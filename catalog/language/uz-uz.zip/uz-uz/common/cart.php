<?php
// Matn
$_['text_items']                 = 'Mahsulotlar %s (%s)';
$_['text_points']                = 'Bonus ballar';
$_['text_subscription']          = 'Obuna bo\'lish';
$_['text_subscription_trial']    = '%d ta to\'lovgacha har %d %s uchun %s dan olinadi';
$_['text_subscription_duration'] = '%d ta to\'lovgacha har %d %s uchun %s dan olinadi';
$_['text_subscription_cancel']   = '%d to\'lov uchun har %d %s uchun %s dan olinadi';
$_['text_day']                   = 'kun';
$_['text_week']                  = 'hafta';
$_['text_semi_month']            = 'yarmoy';
$_['text_month']                 = 'oy';
$_['text_year']                  = 'yil';
$_['text_no_results']            = 'Sizning savatingiz bo\'sh!';
$_['text_cart']                  = 'Savatga o\'tish';
$_['text_checkout']              = 'Buyurtma berish';

// Xatolik
$_['error_product']              = 'Diqqat: Mahsulot topilmadi!';
