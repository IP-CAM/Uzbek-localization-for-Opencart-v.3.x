<?php
// Sarlavha
$_['heading_title']    = 'Xizmat qilish holati';

// Matn
$_['text_maintenance'] = 'Do\'kon vaqtincha yopilgan';
$_['text_message']     = '<h1 style="text-align:center;">Do\'kon vaqtincha yopilgan. Biz profilaktika ishlarni amalga oshiramiz.<br />Tez orada do\'konga kirishingiz mumkin. Iltimos, keyinroq qayting.</h1>';
