<?php
// Matn
$_['text_success']          = 'To‘lov usuli muvofaqqiyatli tanlandi!';

// Xatolik
$_['error_payment_address'] = 'Diqqat: To‘lov manzili kerak!';
$_['error_payment_method']  = 'Diqqat: To‘lov usuli kerak!';
$_['error_no_payment']      = 'Mavjud to‘lov usullari yo‘q. Iltimos, <a href="%s">ma’muriyat bilan bog‘laning!</a>';
$_['error_product']         = 'Diqqat! Mahsulotlar kerak';
