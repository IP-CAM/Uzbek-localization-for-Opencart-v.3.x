<?php
// Matn
$_['text_cart']       = 'Xarid savatchasi muvofaqqiyatli yangilandi!';
$_['text_for']        = '%s Pullik sertifikat uchun %s';
$_['text_success']    = 'Sertifikat chegirma muvofaqqiyatli amalga oshirildi!';
$_['text_remove']     = 'Sertifikat muvofaqqiyatli o‘chirildi!';

// Xatolik
$_['error_voucher']    = 'Sertifikat topilmadi!';
$_['error_to_name']    = 'Qabul qiluvchi ismi 1 dan 64 gacha belgidan iborat bo‘lishi kerak!';
$_['error_from_name']  = 'Sizning ismingiz 1 dan 64 gacha belgidan iborat bo‘lishi kerak!';
$_['error_email']      = 'To‘g‘ri E-mail kiriting!';
$_['error_theme']      = 'Sertifikat mavzusini tanlang!';
$_['error_amount']     = 'Diqqat. Summa %s dan katta va %s dan kichik bo‘lishi kerak!';
