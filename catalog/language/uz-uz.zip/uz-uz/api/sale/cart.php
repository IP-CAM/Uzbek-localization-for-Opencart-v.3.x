<?php
// Matn
$_['text_success']               = 'Savatcha muvofaqqiyatli o‘zgartirildi!';
$_['text_subscription']          = 'Obuna';
$_['text_subscription_trial']    = '%d %s har bir %d %s uchun, keyingi %d to‘lov uchun';
$_['text_subscription_duration'] = '%d %s har bir %d %s uchun, keyingi %d to‘lov uchun';
$_['text_subscription_cancel']   = '%d %s har bir %d %s gacha bekor qilinmasa qadar';
$_['text_day']                   = 'kun';
$_['text_week']                  = 'hafta';
$_['text_semi_month']            = 'yarmoy oyi';
$_['text_month']                 = 'oy';
$_['text_year']                  = 'yil';
$_['text_for']                   = '%s Sertifikat uchun %s ga';

// Xatolik
$_['error_stock']                = '*** belgilangan mahsulotlar kerakli miqdorda yoki omborda mavjud emas!';
$_['error_minimum']              = 'Mahsulotni buyurtma qilish uchun minimal miqdor %s %s!';
$_['error_store']                = 'Tanlangan do‘koningizda ushbu mahsulotni sotib olish mumkin emas!';
$_['error_required']             = '%s majburiy!';
$_['error_product']              = 'Savatchada mahsulot yo‘q!';
$_['error_subscription']         = 'Obuna rejalashtirishni tanlang!';
