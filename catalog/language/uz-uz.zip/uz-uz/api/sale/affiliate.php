<?php
// Matn
$_['text_success']    = 'Hamkorlik komissiyasi muvofaqqiyatli qo‘llab-quvvatlandi!';
$_['text_remove']     = 'Hamkorlik komissiyasi muvofaqqiyatli o‘chirildi!';

// Xatolik
$_['error_affiliate'] = 'Diqqat: Hamkor topilmadi!';
