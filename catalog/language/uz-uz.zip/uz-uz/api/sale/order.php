<?php
// Matn
$_['text_success']           = 'Buyurtma muvofaqqiyatli o‘zgartirildi!';

// Xatolik
$_['error_order']            = 'Diqqat: Buyurtma topilmadi!';
$_['error_customer']         = 'Diqqat: Mijoz ma’lumotlari kerak!';
$_['error_payment_address']  = 'Diqqat: To‘lov manzili kerak!';
$_['error_payment_method']   = 'Diqqat: To‘lov uslubini tanlash kerak!';
$_['error_no_payment']       = 'Diqqat: To‘lov variantlari mavjud emas!';
$_['error_shipping_address'] = 'Diqqat: Yetkazib berish manzili kerak!';
$_['error_shipping_method']  = 'Diqqat: Yetkazib berish uslubini tanlash kerak!';
$_['error_no_shipping']      = 'Diqqat: Yetkazib berish variantlari mavjud emas!';
$_['error_stock']            = 'Diqqat: ** belgilangan maxsulotlar, talab etilgan miqdorda mavjud emas yoki omborda yo‘q!';
$_['error_minimum']          = 'Diqqat: %s uchun minimal buyurtma summasi %s!';
$_['error_product']          = 'Diqqat: Maxsulot qo‘shishingiz kerak!';
$_['error_comment']          = 'Diqqat: Izohlarni qo‘shishingiz kerak!';
