<?php
// Matn
$_['text_success']         = 'Mijoz muvofaqqiyatli yangilandi';

// Xatolik
$_['error_customer']       = 'Diqqat: Mijoz topilmadi!';
$_['error_customer_group'] = 'Mijoz guruh mavjud emas!';
$_['error_firstname']      = 'Ism 1 dan 32 belgidan iborat bo‘lishi kerak!';
$_['error_lastname']       = 'Familiya 1 dan 32 belgidan iborat bo‘lishi kerak!';
$_['error_email']          = 'E-Mail manzili noto‘g‘ri kiritildi!';
$_['error_telephone']      = 'Telefon raqami 3 dan 32 belgidan iborat bo‘lishi kerak!';
$_['error_custom_field']   = '%s talab qilinadi!';
$_['error_regex']          = '%s noto‘g‘ri kiritilgan!';
