<?php
// Matn
$_['text_success']  = 'Bonus ball muvofaqqiyatli qo‘llab-quvvatlandi!';
$_['text_remove']   = 'Bonus ball o‘chirildi!';

// Xatolik
$_['error_reward']  = 'Iltimos, ushbu buyurtmani to‘lash uchun bonus ball miqdorini kiriting!';
$_['error_points']  = 'Sizda %s bonus ball yo‘q!';
$_['error_maximum'] = 'To‘lash uchun qo‘llaniladigan maksimal bonus ball miqdori: %s!';
