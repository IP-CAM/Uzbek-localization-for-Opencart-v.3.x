<?php
// Matn
$_['text_success']            = 'Yetkazib berish usuli muvofaqqiyatli tanlandi!';

// Xatolik
$_['error_shipping_address']  = 'Diqqat: Yetkazib berish manzili kerak!';
$_['error_shipping_method']   = 'Diqqat: Yetkazib berish usuli kerak!';
$_['error_no_shipping']       = 'Yetkazib berish usullari mavjud emas. Iltimos <a href="%s">biz bilan bog‘laning</a> admin bilan bog‘laning!';
$_['error_shipping']          = 'Diqqat: Yetkazib berish talab qiladigan mahsulot yo‘q';
