<?php
// Matn
$_['text_success'] = 'Kupon muvofaqqiyatli qo‘llandi!';
$_['text_remove']  = 'Kupon muvofaqqiyatli o‘chirildi!';

// Xatolik
$_['error_coupon']  = 'Xatolik. Noto‘g‘ri Chegirma Kuponi kodi. Mumkin, amal qilish muddati tugagan yoki ishlatish chegarasi tushgan!';
