<?php
// Matn
$_['text_success']          = 'Yetkazib berish manzili muvofaqqiyatli tanlandi!';

// Xatolik
$_['error_firstname']       = 'Ism 1 dan 32 belgiga bo‘lishi kerak!';
$_['error_lastname']        = 'Familiya 1 dan 32 belgiga bo‘lishi kerak!';
$_['error_address_1']       = 'Manzil 3 dan 128 belgiga bo‘lishi kerak!';
$_['error_city']            = 'Shahar nomi 2 dan 128 belgiga bo‘lishi kerak!';
$_['error_postcode']        = 'Pochta indeksi 2 dan 10 belgiga bo‘lishi kerak!';
$_['error_country']         = 'Iltimos, mamlakatni tanlang!';
$_['error_zone']            = 'Iltimos, hudud / viloyatni tanlang';
$_['error_custom_field']    = '%s zarur!';
$_['error_regex']           = '%s noto‘g‘ri kiritilgan!';
$_['error_shipping']        = 'Diqqat: Yetkazib berish talab qiladigan mahsulot yo‘q';
