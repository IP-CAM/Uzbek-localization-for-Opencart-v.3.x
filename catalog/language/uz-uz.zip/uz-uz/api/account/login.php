<?php
// Matn
$_['text_success']     = 'API sessiyasi muvofaqqiyatli boshlandi!';

// Xatolik
$_['error_permission'] = 'Diqqat: Sizga API ga kirish uchun ruxsat berilmagan!';
$_['error_key']        = 'Diqqat: Noto‘g‘ri API kaliti!';
$_['error_ip']         = 'Diqqat: Sizning IP manzilingizga (%s) ushbu API ga kirish uchun ruxsat etilmagan!';
