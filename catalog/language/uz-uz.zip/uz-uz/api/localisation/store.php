<?php
// Matn
$_['text_success'] = 'Do‘kon muvofaqqiyatli o‘zgartirildi!';

// Xatolik
$_['error_store']  = 'Diqqat: Do‘kon topilmadi!';
