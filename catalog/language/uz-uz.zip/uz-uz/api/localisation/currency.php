<?php
// Matn
$_['text_success']   = 'Valyuta muvofaqqiyatli o‘zgartirildi!';

// Xatolik
$_['error_currency'] = 'Diqqat: Valyuta topilmadi!';
