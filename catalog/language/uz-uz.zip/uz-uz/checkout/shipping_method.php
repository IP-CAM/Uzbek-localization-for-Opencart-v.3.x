<?php
// Sarlavha
$_['heading_title']          = 'Yetkazib berish usuli';

// Matn
$_['text_shipping_method']   = 'Yetkazib berish usulining sozlamalari';
$_['text_shipping']          = 'Iltimos, ushbu buyurtma uchun afzal ko\'riladigan yetkazib berish usulini tanlang.';
$_['text_success']           = 'Yetkazib berish usuli o\'zgartirildi!';
$_['button_choose']          = 'Tanlang';

// Kiritish
$_['entry_shipping_method']   = 'Yetkazib berish usulini tanlang...';

// Xato
$_['error_customer']          = 'Mijoz talab qilinadi!';
$_['error_payment_address']   = 'To\'lov manzili talab qilinadi!';
$_['error_shipping_address']  = 'Diqqat: Yetkazib berish manzili talab qilinadi!';
$_['error_shipping_method']   = 'Diqqat: Yetkazib berish usuli talab qilinadi!';
$_['error_no_shipping']       = 'Ushbu yetkazib berish usuli mavjud emas. Iltimos <a href="%s">biz bilan bog\'laning</a> !';
