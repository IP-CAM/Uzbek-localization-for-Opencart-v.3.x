<?php
// Sarlavha
$_['heading_title'] = 'Buyurtma olish';

// Matn
$_['text_cart']     = 'Xarid savatchasi';
