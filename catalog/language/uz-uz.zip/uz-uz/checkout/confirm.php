<?php
// Matn
$_['text_points']                = 'Bonus ballar';
$_['text_subscription']          = 'Obuna';
$_['text_subscription_trial']    = '%d to\'g\'ri %s uchun har %d %s uchun';
$_['text_subscription_duration'] = '%d to\'g\'ri %s uchun har %d %s uchun';
$_['text_subscription_cancel']   = '%d to\'g\'ri %s uchun har %d %s uchun';
$_['text_day']                   = 'kun';
$_['text_week']                  = 'hafta';
$_['text_semi_month']            = 'yarmoy';
$_['text_month']                 = 'oy';
$_['text_year']                  = 'yil';

// Ustun
$_['column_name']                = 'Nomi';
$_['column_model']               = 'Modeli';
$_['column_quantity']            = 'Miqdori';
$_['column_price']               = 'Bir donasi narxi';
$_['column_total']               = 'Jami';
