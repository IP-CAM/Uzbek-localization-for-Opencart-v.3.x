<?php
// Sarlavha
$_['heading_title']        = 'Sizning buyurtmangiz qabul qilindi!';

// Matn
$_['text_basket']          = 'Savatcha';
$_['text_checkout']        = 'Buyurtmani rasmiylashtirish';
$_['text_success']         = 'Buyurtma qabul qilindi';
$_['text_customer']        = '<p>Sizning buyurtmangiz qabul qilindi!</p><p>Buyurtmangiz tarixi <a href="%s">Shaxsiy kabinetda</a> joylashgan. Tarixni ko\'rish uchun, iltimos, quyidagi havolaga o\'ting <a href="%s">Buyurtmalar tarixi</a>.</p><p>Agar sotuvingiz raqamli mahsullar bilan bog\'liq bo\'lsa, iltimos, ko\'rish yoki yuklab olish uchun quyidagi sahifaga o\'ting <a href="%s">Yuklab olish uchun fayllar</a>.</p><p>Agar savollaringiz bo\'lsa, iltimos <a href="%s">biz bilan bog\'laning</a>.</p><p>Sizning xaridlar uchun rahmat!</p>';
$_['text_guest']           = '<p>Sizning buyurtmangiz qabul qilindi!</p><p>Agar savollaringiz bo\'lsa, iltimos, <a href="%s">biz bilan bog\'laning</a>.</p><p>Sizning xaridlar uchun rahmat!</p>';
