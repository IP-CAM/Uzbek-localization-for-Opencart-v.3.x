<?php
// Sarlavha
$_['heading_title'] = 'To\'lov xatosi!';

// Matn
$_['text_basket']   = 'Xarid savati';
$_['text_checkout'] = 'Buyurtmani rasmiylashtirish';
$_['text_failure']  = 'To\'lov xatosi';
$_['text_message']  = '<p>To\'lov jarayonida xatolik yuzaga keldi. Xatolik sababi tufayli buyurtmani rasmiylashtirib bo\'lmadi</p><p>Mumkin xatolik sabablari:</p><ul><li>Mablag\' yetarli emas</li><li>Tekshiruvda xatolik</li></ul> <p>Iltimos, to\'lov usulini tanlash orqali qayta urinib ko\'ring.</p><p>Agar xato qaytarilsa, iltimos, <a href="%s">menejer bilan bog\'laning</a> va buyurtma detallarini xabar bering.</p>';
