<?php
// Sarlavha
$_['heading_title']    = 'Sayt xaritasi';

// Matn
$_['text_special']     = 'Aksiyalar';
$_['text_account']     = 'Shaxsiy kabinet';
$_['text_edit']        = 'Shaxsiy ma’lumotlar';
$_['text_password']    = 'Parol';
$_['text_address']     = 'Mening manzillarim';
$_['text_history']     = 'Buyurtmalar tarixi';
$_['text_download']    = 'Yuklab olingan fayllar';
$_['text_cart']        = 'Savatcha';
$_['text_checkout']    = 'Buyurtmani rasmiylashtirish';
$_['text_search']      = 'Qidirish';
$_['text_information'] = 'Ma’lumot';
$_['text_contact']     = 'Bizning aloqalar';
