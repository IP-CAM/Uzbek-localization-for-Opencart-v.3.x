<?php
// Sarlavha
$_['heading_title'] = 'GDPR so‘rovi yuborildi';

// Matn
$_['text_account']  = 'Hisobingiz';
$_['text_export']   = 'Hisobingiz ma\'lumotlarini eksport qilish so\'roq yuborildi';
$_['text_remove']   = 'GDPR hisobni o\'chirish so\'rovi <strong>%s kun ichida</strong> bajariladi, to\'lov qaytarish, to\'lovni qaytarish yoki g\'alati aniqlanishni bajarish uchun.';
