<?php
// Matn
$_['text_error'] = 'Ma’lumot sahifasi topilmadi!';
