<?php
// Sarlavha
$_['heading_title'] = 'So‘ralgan sahifa topilmadi!';

// Matn
$_['text_error']    = 'Afsuski, so‘ralgan sahifa topilmadi. Ehtimol, siz mavjud bo‘lmagan manzilni kiritingiz, sahifa o‘chirilgan yoki ko‘chirilgan yoki hozircha faol emas!';
