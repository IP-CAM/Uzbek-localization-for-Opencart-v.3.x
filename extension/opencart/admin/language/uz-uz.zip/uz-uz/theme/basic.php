<?php
// Sarlavha
$_['heading_title']    = 'Standart mavzu';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Kiritish
$_['entry_status']     = 'Holat';

// Xatolik
$_['error_permission'] = 'Sizda sozlamalarni o\'zgartirish uchun huquq yo\'q!';
