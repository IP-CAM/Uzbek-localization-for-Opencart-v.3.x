<?php
// Sarlavha
$_['heading_title']    = 'Markaziy Bank Evro valyuta konvertori';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul Sozlamalari';
$_['text_support']     = 'Ushbu kengaytma uchun Euro valyutasi mavjud bo\'lishi kerak.';

// Kirish
$_['entry_status']     = 'Status';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
