<?php
// Sarlavha
$_['heading_title']    = 'Fixer - Valyuta ayirboshlash xizmati';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul Sozlamalari';
$_['text_signup']      = 'Fixer.io - bu valyuta konvertatsiya xizmati <a href="https://fixer.io/" target="_blank" class="alert-link">bu yerda ro\'yxatdan o\'ting</a>.';
$_['text_support']     = 'Ushbu kengaytma uchun Euro valyutasi mavjud bo\'lishi kerak.';

// Kiritish
$_['entry_api']        = 'API kirish kaliti';
$_['entry_status']     = 'Status';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
$_['error_api']        = 'API kirish kaliti kerak!';
