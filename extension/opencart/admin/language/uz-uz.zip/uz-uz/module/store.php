<?php
// Heading
$_['heading_title']    = 'Do\'kon';

// Text
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Kengaytma sozlamalari';

// Kirish
$_['entry_admin']      = 'Faqat administratorlar';
$_['entry_status']     = 'Holat';

// Xatolik
$_['error_permission'] = 'Sizda ushbu kengaytmani boshqarish uchun huquqlar yo\'q!';
