<?php
// Heading
$_['heading_title']     = 'Matn bloki - HTML';

// Text
$_['text_extension']    = 'Kengaytmalar';
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']         = 'Kengaytma sozlamalari';

// Kirish
$_['entry_name']        = 'Kengaytma nomi';
$_['entry_title']       = 'Sarlavha';
$_['entry_description'] = 'Matn';
$_['entry_status']      = 'Holat';

// Xatolik
$_['error_permission']  = 'Sizda ushbu kengaytmani boshqarish uchun huquqlar yo\'q!';
$_['error_name']        = 'Kengaytma nomi 3 dan 64 belgidan kam bo\'lmasligi kerak!';
