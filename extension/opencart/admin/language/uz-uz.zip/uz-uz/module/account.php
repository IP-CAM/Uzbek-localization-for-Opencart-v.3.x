<?php
// Sarlavha
$_['heading_title']    = 'Hisob';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul sozlamalari';

// Kirish
$_['entry_status']     = 'Holat';

// Xatolik
$_['error_permission'] = 'Sizda "Hisob" modulini o\'zgartirish huquqi yo\'q!';
