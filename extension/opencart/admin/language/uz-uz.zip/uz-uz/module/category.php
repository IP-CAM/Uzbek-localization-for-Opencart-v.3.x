<?php
// Sarlavha
$_['heading_title']    = 'Kategoriyalar';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Kengaytma sozlamalari';

// Kirish
$_['entry_status']     = 'Holat';

// Xatolik
$_['error_permission'] = 'Sizda ushbu kengaytmani boshqarish uchun huquqlar yo\'q!';
