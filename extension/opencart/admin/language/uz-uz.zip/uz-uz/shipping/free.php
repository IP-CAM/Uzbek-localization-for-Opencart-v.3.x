<?php
// Sarlavha
$_['heading_title']    = 'Bepul yetkazib berish';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Kiritish
$_['entry_total']      = 'Limit summa';
$_['entry_geo_zone']   = 'Geografik zona';
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Yordam
$_['help_total']       = 'Bepul yetkazib berishdan foydalanish uchun kerak bo\'lgan minimal buyurtma miqdori.';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
