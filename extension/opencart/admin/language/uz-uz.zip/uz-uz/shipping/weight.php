<?php
// Sarlavha
$_['heading_title']    = 'Og\'irlik bo\'yicha yetkazib berish';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Kiritish
$_['entry_rate']       = 'Narxlar';
$_['entry_tax_class']  = 'Nalog klassi';
$_['entry_geo_zone']   = 'Geografik zona';
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Yordam
$_['help_rate']        = 'Misol: 5:10.00,7:12.00 Og\'irlik:Narx,Og\'irlik:Narx, va h.k. (Kg yoki boshqa belgilarni kiritingmaslik)';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
