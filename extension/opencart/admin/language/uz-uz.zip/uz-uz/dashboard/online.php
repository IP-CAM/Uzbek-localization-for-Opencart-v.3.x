<?php
// Sarlavha
$_['heading_title']    = 'Onlayn Foydalanuvchilar';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';
$_['text_view']        = 'Batafsil...';

// Kiritish
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Taxlilash tartibi';
$_['entry_width']      = 'Kenglik';

// Xatolik
$_['error_permission'] = 'Sizda ushbu kengaytmani boshqarish huquqi yo\'q!';
