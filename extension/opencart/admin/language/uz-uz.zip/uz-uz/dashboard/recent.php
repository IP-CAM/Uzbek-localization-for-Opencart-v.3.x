<?php
// Sarlavha
$_['heading_title']     = 'So\'nggi buyurtmalar';

// Matn
$_['text_extension']    = 'Kengaytmalar';
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']         = 'Tahrirlash';

// Ustunlar
$_['column_order_id']   = '№';
$_['column_customer']   = 'Xaridor';
$_['column_status']     = 'Holat';
$_['column_total']      = 'Umumiy summa';
$_['column_date_added'] = 'Qo\'shilgan vaqti';
$_['column_action']     = 'Harakatlar';

// Kirish
$_['entry_status']      = 'Holat';
$_['entry_sort_order']  = 'Taxlilash tartibi';
$_['entry_width']       = 'Kenglik';

// Xatolik
$_['error_permission']  = 'Sizda ushbu kengaytmani boshqarish huquqi yo\'q!';
