<?php
// Heading
$_['heading_title']      = 'Naqt to\'lov';

// Text
$_['text_extension']     = 'Kengaytmalar';
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';

// Kirish
$_['entry_payable']      = 'Qabul qiluvchi';
$_['entry_order_status'] = 'Buyurtma holati saqlanganidan so\'ng';
$_['entry_geo_zone']     = 'Geografik zona';
$_['entry_status']       = 'Holat';
$_['entry_sort_order']   = 'Taxtirish tartibi';

// Xatolik
$_['error_permission']   = 'Sizda ushbu kengaytmani boshqarish uchun huquqlar yo\'q!';
$_['error_payable']      = 'Qabul qiluvchini kiriting!';
