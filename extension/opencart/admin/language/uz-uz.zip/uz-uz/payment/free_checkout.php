<?php
// Sarlavha
$_['heading_title']      = 'Bepul buyurtma';

// Matn
$_['text_extension']     = 'Kengaytmalar';
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']          = 'Tahrirlash';

// Kiritish
$_['entry_order_status'] = 'Buyurtma holati';
$_['entry_status']       = 'Holat';
$_['entry_sort_order']   = 'Saralash tartibi';

// Xatolik
$_['error_permission']   = 'Ushbu kengaytmani boshqarish huquqingiz yo\'q!';
