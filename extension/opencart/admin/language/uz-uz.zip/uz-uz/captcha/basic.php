<?php
// Sarlavha
$_['heading_title']    = 'Oddiy Himoya';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Modul Sozlamalari';

// Kirish
$_['entry_status']     = 'Status';

// Xatolik
$_['error_permission'] = 'Bu modulni boshqarishga ruxsat etilgan emas!';
