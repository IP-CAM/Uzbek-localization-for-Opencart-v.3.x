<?php
// Sarlavha
$_['heading_title']    = 'Buyurtma ishlovi uchun to\'lov';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Kiritish
$_['entry_total']      = 'Buyurtma summasi';
$_['entry_fee']        = 'To\'lov';
$_['entry_tax_class']  = 'Naloglar';
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Yordam
$_['help_total']       = 'To\'lovi amal qilishi uchun buyurtma summasi chegarasi';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
