<?php
// Sarlavha
$_['heading_title']    = 'Minimal buyurtma uchun qo\'shimcha to\'lov';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']        = 'Tahrirlash';

// Kiritish
$_['entry_total']      = 'Buyurtma summasi';
$_['entry_fee']        = 'To\'lov';
$_['entry_tax_class']  = 'Naloglar';
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Yordam
$_['help_total']       = 'To\'lovi amal qilishi uchun minimal buyurtma summasi';

// Xatolik
$_['error_permission'] = 'Sizda ushbu modulni boshqarish huquqi yo\'q!';
