<?php
// Sarlavha
$_['heading_title']    = 'Kuponlar';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_edit']        = 'Tahrirlash';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_filter']      = 'Filtrlash';

// Ustunlar
$_['column_name']      = 'Kupon';
$_['column_code']      = 'Kod';
$_['column_orders']    = 'Buyurtmalar';
$_['column_total']     = 'Jami';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_date_start'] = 'Boshlanish sanasi';
$_['entry_date_end']   = 'Tugallanish sanasi';
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Xatolik
$_['error_permission']  = 'Sizda ushbu kengaytmani boshqarish huquqi yo\'q!';
