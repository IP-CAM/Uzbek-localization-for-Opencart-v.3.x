<?php
// Sarlavha
$_['heading_title']    = 'Tovar ko\'rishlar';

// Matn
$_['text_extension']   = 'Kengaytmalar';
$_['text_edit']        = 'Tahrirlash';
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_progress']    = 'Progress %s dan %s gacha!';

// Ustunlar
$_['column_name']      = 'Tovar nomi';
$_['column_model']     = 'Model';
$_['column_viewed']    = 'Ko\'rishlar';
$_['column_percent']   = 'Foiz';

// Kiritish
$_['entry_status']     = 'Holat';
$_['entry_sort_order'] = 'Saralash tartibi';

// Xatolik
$_['error_permission'] = 'Sizda ushbu kengaytmani boshqarish huquqi yo\'q!';
