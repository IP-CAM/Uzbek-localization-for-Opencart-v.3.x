<?php
// Sarlavha
$_['heading_title']         = 'Mijoz abunaliğiga hisobot';

// Matn
$_['text_extension']        = 'Kengaytmalar';
$_['text_edit']             = 'Mijoz abunaliğiga hisobotni tahrirlash';
$_['text_success']          = 'Siz mijoz abunaliğiga hisobotni o\'zgardi!';
$_['text_filter']           = 'Filtrlash';

// Ustunlar
$_['column_customer']       = 'Ismi';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Guruh';
$_['column_status']         = 'Holat';
$_['column_total']          = 'Jami';
$_['column_action']         = 'Harakat';

// Kiritish
$_['entry_date_start']      = 'Boshlanish sanasi';
$_['entry_date_end']        = 'Tugallanish sanasi';
$_['entry_customer']        = 'Mijoz';
$_['entry_status']          = 'Holat';
$_['entry_sort_order']      = 'Saralash tartibi';

// Xatolik
$_['error_permission']      = 'Mijoz abunaliğiga hisobotni o\'zgartirish huquqingiz yo\'q!';
