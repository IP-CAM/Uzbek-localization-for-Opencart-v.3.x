<?php
// Sarlavha
$_['heading_title']         = 'Mijoz tranzaksiyalari';

// Matn
$_['text_extension']        = 'Kengaytmalar';
$_['text_edit']             = 'Tahrirlash';
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_filter']           = 'Filtrlash';

// Ustunlar
$_['column_customer']       = 'Mijoz';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Guruh';
$_['column_status']         = 'Holat';
$_['column_total']          = 'Jami';
$_['column_action']         = 'Harakat';

// Kiritish
$_['entry_date_start']      = 'Boshlanish sanasi';
$_['entry_date_end']        = 'Tugallanish sanasi';
$_['entry_customer']        = 'Mijoz';
$_['entry_status']          = 'Holat';
$_['entry_sort_order']      = 'Saralash tartibi';

// Xatolik
$_['error_permission']      = 'Sizda ushbu kengaytmani boshqarish huquqi yo\'q!';
