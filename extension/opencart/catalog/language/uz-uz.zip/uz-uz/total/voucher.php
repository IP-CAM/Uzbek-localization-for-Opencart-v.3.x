<?php
// Sarlavha
$_['heading_title'] = 'Podarochniy sertifikatni ishlatish';

// Matn
$_['text_voucher']  = 'Podarochniy sertifikat (%s)';
$_['text_success']  = 'Sizning Podarochniy sertifikatingiz muvaffaqiyatli qo\'llandi!';
$_['text_remove']   = 'Muvaffaqiyat: Sizning podarochniy sertifikat chegirma olib tashlandi!';

// Kiritish
$_['entry_voucher'] = 'Podarochniy sertifikat kodingizni kiriting';

// Xatolik
$_['error_voucher'] = 'Xatolik. Noto\'g\'ri Podarochniy sertifikat kodi yoki ushbu sertifikat allaqachon ishlatilgan!';
$_['error_status']  = 'Podarochniy sertifikat ushbu do\'konni yoqmaydi!';
