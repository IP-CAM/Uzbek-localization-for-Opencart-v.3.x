<?php
// Sarlavha
$_['heading_title'] = 'Kuponni ishlatish';

// Matn
$_['text_coupon']   = 'Kupon (%s)';
$_['text_success']  = 'Chegirma kupon muvaffaqiyatli qo\'llandi!';
$_['text_remove']   = 'Chegirma kupon muvaffaqiyatli o\'chirildi!';

// Kiritish
$_['entry_coupon']  = 'Kupon kodingizni kiriting';

// Xatolik
$_['error_coupon']  = 'Xatolik. Noto\'g\'ri Chegirma kupon kodi. Mumkin, amal qilish muddati tugagan yoki qo\'llanish chegarasi etib ketgan!';
$_['error_status']  = 'Kuponlar ushbu do\'kon tomonidan yoqilmagan!';
