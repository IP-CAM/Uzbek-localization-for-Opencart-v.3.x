<?php
// Sarlavha
$_['heading_title'] = 'Bonus ballarni ishlatish (mavjud ballar %s)';

// Matn
$_['text_reward']   = 'Bonus ballar (%s)';
$_['text_order_id'] = 'Buyurtma raqami: %s';
$_['text_success']  = 'Ballar muvaffaqiyatli qo\'llandi!';
$_['text_remove']   = 'Ballar muvaffaqiyatli o\'chirildi!';

// Kiritish
$_['entry_reward']  = 'Ishlatish uchun mavjud (maksimum %s)';

// Xatolik
$_['error_reward']  = 'Iltimos, buyurtma uchun bonus ballarni ko\'rsating!';
$_['error_points']  = 'Sizda %s bonus ballar yo\'q!';
$_['error_maximum'] = 'Ishlatilishi mumkin bo\'lgan maksimal ballar soni: %s!';
$_['error_status']  = 'Bonus ballar ushbu do\'kon tomonidan yoqilmagan!';
