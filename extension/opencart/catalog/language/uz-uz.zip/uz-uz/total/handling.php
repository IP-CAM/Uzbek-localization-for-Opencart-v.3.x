<?php
// Text
$_['text_handling'] = 'Buyurtmani qayta ishlash uchun to\'lov';