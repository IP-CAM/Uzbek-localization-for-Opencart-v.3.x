<?php
// Matn
$_['text_low_order_fee'] = 'Minimal buyurtma uchun qo\'shimcha to\'lov';
