<?php
// Sarlavha
$_['heading_title']        = 'Yetkazib berishda to\'lov';

// Xatolik
$_['error_order_id']       = 'Xatolik: Sessiyada buyurtma identifikatorini yo\'q!';
$_['error_payment_method'] = 'Noto\'g\'ri to\'lov usuli!';
