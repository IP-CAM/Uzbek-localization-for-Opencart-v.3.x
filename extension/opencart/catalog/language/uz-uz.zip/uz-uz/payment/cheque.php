<?php
// Sarlavha
$_['heading_title']    = 'Naqd pul to\'lash';

// Matn
$_['text_instruction'] = 'Naqd pul to\'lash. Qo\'llanma';
$_['text_payable']     = 'To\'lov qabul qiluvchi: ';
$_['text_address']     = 'To\'lov manzili: ';
$_['text_payment']     = 'Pul kelmaguncha buyurtmangiz ishlanmaydi.';
