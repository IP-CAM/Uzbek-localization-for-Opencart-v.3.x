<?php
// Sarlavha
$_['heading_title']       = 'Bank kartadan to\'lash';

// Matn
$_['text_instruction'] = 'Bank kartasidan to\'lash bo\'yicha qo\'llanma';
$_['text_description'] = 'Iltimos, umumiy summani quyidagi hisobga o\'tirishingizni so\'raymiz: shu manzil';
$_['text_payment']     = 'Pullar hisobimizga kelmasa, buyurtma ishlanmaydi.';
