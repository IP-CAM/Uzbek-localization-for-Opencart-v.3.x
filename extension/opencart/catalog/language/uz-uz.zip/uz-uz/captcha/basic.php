<?php
// Matn
$_['text_captcha']  = 'Robotlardan himoya';

// Kiritish
$_['entry_captcha'] = 'Quyidagi maydonchaga kodingizni kiriting';

// Xatolik
$_['error_captcha'] = 'Tekshiruv kodi tasvir bilan mos kelmadi!';
