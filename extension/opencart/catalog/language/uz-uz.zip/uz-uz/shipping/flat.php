<?php
// Heading
$_['heading_title']    = 'O\'rnatilgan yetkazib berish narxi';

// Text
$_['text_description'] = 'O\'rnatilgan narx bo\'yicha yetkazib berish';