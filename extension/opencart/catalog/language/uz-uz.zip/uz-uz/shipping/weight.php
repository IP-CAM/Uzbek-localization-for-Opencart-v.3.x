<?php
// Heading
$_['heading_title'] = 'Og\'irlikka qarab yetkazib berish';

// Text
$_['text_weight']   = 'Og\'irlik:';