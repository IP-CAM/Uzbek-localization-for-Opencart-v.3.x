<?php
// Sarlavha
$_['heading_title']    = 'O\'z o\'zidan olish';

// Matn
$_['text_description'] = 'Do\'konimizdan o\'z o\'zingizdan olish';
