<?php
// Heading
$_['heading_title']    = 'Bepul yetkazib berish';

// Text
$_['text_description'] = 'Bepul yetkazib berish';