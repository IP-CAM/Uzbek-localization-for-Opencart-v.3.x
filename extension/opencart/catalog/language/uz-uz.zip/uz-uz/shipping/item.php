<?php
// Sarlavha
$_['heading_title']    = 'Har bir mahsulot uchun';

// Matn
$_['text_description'] = 'Har bir mahsulot uchun to\'lov narxi';
