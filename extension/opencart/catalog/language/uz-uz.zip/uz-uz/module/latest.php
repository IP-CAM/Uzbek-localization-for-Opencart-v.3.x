<?php
// Heading
$_['heading_title'] = 'So\'ngi qo\'shilganlar';