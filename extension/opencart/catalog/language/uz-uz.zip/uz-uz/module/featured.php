<?php
// Heading
$_['heading_title'] = 'Tavsiya qilinganlar';