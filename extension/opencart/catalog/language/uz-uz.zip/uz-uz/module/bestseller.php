<?php
// Heading
$_['heading_title'] = 'Ommabop mahsulotlar';