<?php
// Sarlavha
$_['heading_title']    = 'Shaxsiy kabinet';

// Matn
$_['text_register']    = 'Ro\'yxatdan o\'tish';
$_['text_login']       = 'Kirish';
$_['text_logout']      = 'Chiqish';
$_['text_forgotten']   = 'Parolni unutdingizmi?';
$_['text_account']     = 'Mening ma\'lumotlarim';
$_['text_edit']        = 'Kontakt ma\'lumotlarni tahrirlash';
$_['text_password']    = 'Parol';
$_['text_address']     = 'Manzillar kitobi';
$_['text_wishlist']    = 'Sevimlilar';
$_['text_order']       = 'Buyurtmalar tarixi';
$_['text_download']    = 'Yuklamalar';
$_['text_reward']      = 'Bonus ballar';
$_['text_return']      = 'Qaytarishlar';
$_['text_transaction'] = 'Tranzaksiya tarixi';
$_['text_newsletter']  = 'E-Mail ro\'yxatdan o\'tish';
$_['text_subscription'] = 'Obuna';

