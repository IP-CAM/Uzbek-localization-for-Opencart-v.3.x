<?php
// Heading
$_['heading_title'] = 'Ma\'lumot';

// Text
$_['text_contact']  = 'Biz bilan bog\'lanish';
$_['text_sitemap']  = 'Sayt xaritasi';