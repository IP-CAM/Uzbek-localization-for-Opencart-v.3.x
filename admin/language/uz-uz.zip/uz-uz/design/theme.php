<?php
// Sarlavha
$_['heading_title']     = 'Shablon tahriri';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_edit']         = 'Tahrirlash';
$_['text_store']        = 'Do\'konni tanlash';
$_['text_template']     = 'Shablonni tanlash';
$_['text_default']      = 'Standart';
$_['text_extension']    = 'Modullar / Kengaytmalar';
$_['text_history']      = 'Tarix';
$_['text_twig']         = 'Shablon tahriri Twig shablonlash tilidan foydalanadi. Batafsilroq <a href="http://twig.sensiolabs.org/documentation" target="_blank" class="alert-link">Twig sintaksisi haqida, bu erda</a> o\'qishingiz mumkin.';

// Ustunlar
$_['column_store']      = 'Do\'kon';
$_['column_route']      = 'Yo\'l';
$_['column_date_added'] = 'Qo\'shilgan sana';
$_['column_action']     = 'Harakat';

// Xatoliklar
$_['error_permission']  = 'Sizda sozlamalarni o\'zgartirish uchun ruxsat yo\'q!';
$_['error_twig']        = 'Diqqat: Faylni faqat .twig kengaytmasi bilan saqlashingiz mumkin!';
