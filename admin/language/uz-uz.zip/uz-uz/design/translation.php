<?php
// Sarlavha
$_['heading_title']    = 'Til tahriri';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Til tahriri';
$_['text_add']         = 'Tarjimani qo\'shish';
$_['text_edit']        = 'Tahrirlash';
$_['text_default']     = 'Standart';
$_['text_store']       = 'Do\'kon';
$_['text_language']    = 'Til';

// Ustunlar
$_['column_store']     = 'Do\'kon';
$_['column_language']  = 'Til';
$_['column_route']     = 'Yo\'l';
$_['column_key']       = 'Kalit';
$_['column_value']     = 'Qiymat';
$_['column_action']    = 'Harakat';

// Kiritmalar
$_['entry_store']      = 'Do\'kon';
$_['entry_language']   = 'Til';
$_['entry_route']      = 'Yo\'l';
$_['entry_key']        = 'Kalit';
$_['entry_default']    = 'Standart';
$_['entry_value']      = 'Qiymat';

// Xatoliklar
$_['error_permission'] = 'Sizda sozlamalarni o\'zgartirish uchun ruxsat yo\'q!';
$_['error_key']        = 'Kalit 3 dan 64 belgigacha bo\'lishi kerak!';
