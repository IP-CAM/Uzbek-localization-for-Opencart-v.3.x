<?php
// Sarlavha sarlavhasi
$_['heading_title'] = 'Rivojlantirish';
