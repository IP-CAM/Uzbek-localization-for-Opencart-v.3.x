<?php
// Sarlavha
$_['heading_title']    = 'Robotlar qarshi himoya';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Modullar ro‘yxati';

// Ustunlar
$_['column_name']      = 'Nomi';
$_['column_status']    = 'Status';
$_['column_action']    = 'Harakatlar';

// Xatolik
$_['error_permission'] = 'Sizda Robotlar qarshi himoya kengaytmasini tahrirlash uchun huquqlaringiz yo‘q!';
$_['error_extension']  = 'Diqqat: Kengaytma mavjud emas!';
