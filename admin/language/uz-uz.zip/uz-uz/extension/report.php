<?php
// Sarlavha
$_['heading_title']     = 'Hisobotlar';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Hisobotlar ro\'yxati';

// Ustunlar
$_['column_name']       = 'Ismi';
$_['column_status']     = 'Holat';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Xatolik
$_['error_permission']  = 'Sizda "Hisobotlar" kengaytmasini tahrirlashga ruxsat yo\'q!';
$_['error_extension']   = 'Diqqat: Kengaytma mavjud emas!';
