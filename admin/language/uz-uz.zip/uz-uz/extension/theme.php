<?php
// Sarlavha
$_['heading_title']    = 'Mavzular';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli yangilandi!';

// Ustunlar
$_['column_name']      = 'Mavzu nomi';
$_['column_status']    = 'Holat';
$_['column_action']    = 'Harakat';

// Xatolik
$_['error_permission'] = 'Sizda "Mavzular" kengaytmasini tahrirlashga ruxsat yo\'q!';
$_['error_extension']  = 'Diqqat: Kengaytma mavjud emas!';
