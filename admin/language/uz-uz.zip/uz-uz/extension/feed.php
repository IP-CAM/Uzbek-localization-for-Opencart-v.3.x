<?php
// Sarlavha
$_['heading_title']    = 'Reklama kanallari';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Kanal ro‘yxati';

// Ustunlar
$_['column_name']      = 'Kanal nomi';
$_['column_status']    = 'Status';
$_['column_action']    = 'Harakatlar';

// Xatolik
$_['error_permission'] = 'Sizda Reklama kanallari kengaytmasini tahrirlash uchun huquqlaringiz yo‘q!';
$_['error_extension']  = 'Diqqat: Kengaytma mavjud emas!';
