<?php
// Sarlavha
$_['heading_title']     = 'Yetkazib berish';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Yetkazib berish usullarining ro\'yxati';

// Ustunlar
$_['column_name']       = 'Yetkazib berish usuli';
$_['column_status']     = 'Holat';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Xatolik
$_['error_permission']  = 'Sizda "Yetkazib berish" kengaytmasini tahrirlashga ruxsat yo\'q!';
$_['error_extension']   = 'Diqqat: Kengaytma mavjud emas!';
