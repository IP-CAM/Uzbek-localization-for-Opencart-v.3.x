<?php
// Sarlavha
$_['heading_title']    = 'Tillar';

// Matn
$_['text_success']     = 'Tillar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Tillar ro‘yxati';

// Ustunlar
$_['column_name']      = 'Til nomi';
$_['column_status']    = 'Status';
$_['column_action']    = 'Harakatlar';

// Xatolik
$_['error_permission'] = 'Diqqat: Sizda tillarni o‘zgartirishga ruxsat yo‘q!';
$_['error_extension']  = 'Diqqat: Kengaytma mavjud emas!';
