<?php
// Sarlavha
$_['heading_title']     = 'Boshqa';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'Ro‘yxat';

// Ustunlar
$_['column_name']       = 'Ism';
$_['column_status']     = 'Status';
$_['column_action']     = 'Harakatlar';

// Xatolik
$_['error_permission']  = 'Diqqat: Boshqa kategoriyalarni tahrirlashga ruxsat yo‘q!';
$_['error_extension']   = 'Diqqat: Kengaytma mavjud emas!';
