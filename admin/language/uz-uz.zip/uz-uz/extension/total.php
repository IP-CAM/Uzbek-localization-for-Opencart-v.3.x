<?php
// Sarlavha
$_['heading_title']     = 'Buyurtma hisobiga olish';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';

// Ustunlar
$_['column_name']       = 'Buyurtma hisobiga olish';
$_['column_status']     = 'Holat';
$_['column_sort_order'] = 'Tartiblash tartibi';
$_['column_action']     = 'Harakat';

// Xatolik
$_['error_permission']  = 'Sizda "Buyurtma hisobiga olish" kengaytmasini tahrirlashga ruxsat yo\'q!';
$_['error_extension']   = 'Diqqat: Kengaytma mavjud emas!';
