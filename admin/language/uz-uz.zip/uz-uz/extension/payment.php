<?php
// Sarlavha
$_['heading_title']     = 'To‘lov';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli yangilandi!';
$_['text_list']         = 'To‘lov usullarining ro‘yxati';

// Ustunlar
$_['column_name']       = 'To‘lov usuli';
$_['column_vendor']     = 'Razrabotchik';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Saralash tartibi';
$_['column_action']     = 'Harakat';

// Xatolik
$_['error_permission']  = 'Diqqat: To‘lov kengaytmasini tahrirlashga ruxsat yo‘q!';
$_['error_extension']   = 'Diqqat: Kengaytma mavjud emas!';
