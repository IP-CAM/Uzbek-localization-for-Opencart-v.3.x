<?php
// Sarlavha
$_['heading_title']    = 'Tuzuvchi sozlamalari';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_theme']       = 'Mavzu';
$_['text_sass']        = 'SASS';
$_['text_cache']       = 'Siz %s keshini tozaladingiz!';

// Ustun
$_['column_component'] = 'Komponent';
$_['column_action']    = 'Harakat';

// Kirish
$_['entry_theme']      = 'Mavzu';
$_['entry_sass']       = 'SASS';
$_['entry_cache']      = 'Kesh';

// Tugma
$_['button_on']        = 'Yoqilgan';
$_['button_off']       = 'O\'chirilgan';

// Xato
$_['error_permission'] = 'Sizda tuzuvchi sozlamalarni o\'zgartirish uchun ruxsat yo\'q!';
