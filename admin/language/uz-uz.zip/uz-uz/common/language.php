<?php
$_['error_language'] = 'Diqqat: Til topilmadi!';
