<?php
// Sarlavha
$_['heading_title'] = 'Holat paneli';
