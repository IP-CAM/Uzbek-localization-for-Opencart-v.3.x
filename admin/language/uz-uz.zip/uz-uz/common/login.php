<?php
// Sarlavha
$_['heading_title']  = 'Avtorizatsiya';

// Matn
$_['text_heading']   = 'Avtorizatsiya';
$_['text_login']     = 'Login va parolingizni kiriting';
$_['text_forgotten'] = 'Parolingizni unutdingizmi?';

// Kirish
$_['entry_username'] = 'Login';
$_['entry_password'] = 'Parol';

// Tugma
$_['button_login']   = 'Kirish';

// Xato
$_['error_login']    = 'Bunday login yoki parol mavjud emas!';
$_['error_token']    = 'Noto\'g\'ri token-sessiya. Qayta avtorizatsiyadan o\'ting.';
