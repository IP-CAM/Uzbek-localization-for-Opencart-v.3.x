<?php
// Sarlavha
$_['heading_title']          = 'Adminstratsiya';

// Matn
$_['text_notification']      = 'Bildirishnomalar';
$_['text_notification_all']  = 'Hammasini ko\'rsatish';
$_['text_notification_none'] = 'Yangi bildirishnomalar yo\'q';
$_['text_profile']           = 'Sizning profil';
$_['text_store']             = 'Do\'kon';
$_['text_help']              = 'Yordam';
$_['text_homepage']          = 'Veb-sayt';
$_['text_support']           = 'Forum';
$_['text_documentation']     = 'Hujjatlar';
$_['text_logout']            = 'Chiqish';
