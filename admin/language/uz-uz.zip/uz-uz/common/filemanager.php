<?php
// Sarlavha
$_['heading_title']    = 'Rasm boshqaruvchisi';

// Matn
$_['text_uploaded']    = 'Fayl yuklandi!';
$_['text_directory']   = 'Tayyor: Direktoriya yaratildi!';
$_['text_delete']      = 'Fayl yoki direktoriya o\'chirildi!';

// Kirish
$_['entry_search']     = 'Qidirish..';
$_['entry_folder']     = 'Yangi papka';

// Xato
$_['error_permission'] = 'Sizda kirish huquqi yo\'q!';
$_['error_filename']   = 'Fayl nomi 3 dan 255 belgidan iborat bo\'lishi kerak!';
$_['error_folder']     = 'Diqqat: Direktoriya nomi 3 dan 255 belgidan iborat bo\'lishi kerak!';
$_['error_exists']     = 'Bu nomdagi fayl yoki direktoriya allaqachon mavjud!';
$_['error_directory']  = 'Direktoriyani tanlang!';
$_['error_filesize']   = 'Diqqat: Fayl hajmi noto\'g\'ri!';
$_['error_file_type']  = 'Diqqat: Fayl turi noto\'g\'ri!';
$_['error_upload']     = 'Diqqat: Fayl noaniq sababli yuklanmadi!';
$_['error_delete']     = 'Direktoriya o\'chirib bo\'lmaydi!';
