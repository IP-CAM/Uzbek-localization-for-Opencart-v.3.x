<?php
// Matn
$_['text_footer']  = '<HR><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Barcha huquqlar himoyalangan.<br> <BR> <a href="http://opencart-russia.ru" target="_blank">OpenCart Rus versiyasi</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://forum.opencart-russia.ru" target="_blank">Yordam forumi</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://shop.opencart-russia.ru" target="_blank">Qo\'shimcha do\'kon</a>';
$_['text_version'] = 'Versiya trs %s';
