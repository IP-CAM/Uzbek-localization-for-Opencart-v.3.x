<?php
// Matn
$_['text_recommended'] = 'Tavsiya etilgan';
$_['text_install']     = 'O\'rnatish';
$_['text_uninstall']   = 'Deinstalasiyala';
$_['text_delete']      = 'O\'chirish';
