<?php
// Heading
$_['heading_title'] = 'Modullar / Kengaytmalar';

// Text
$_['text_success']  = 'Sozlamalar muvaffaqiyatli saqlandi!';
$_['text_list']     = 'Kengaytmalar ro\'yxati';
$_['text_type']     = 'Kengaytma turini tanlang';
$_['text_filter']   = 'Filter';
