<?php
// Sarlavha
$_['heading_title']     = 'Amallar boshlanishida';

// Matn
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Amallar ro\'yxati';

// Ustun
$_['column_code']       = 'Amal kodi';
$_['column_sort_order'] = 'Tartiblash tartibi';
$_['column_action']     = 'Amal';

// Xatolik
$_['error_permission']  = 'Diqqat: Sizda boshqarish uchun ruxsat yo\'q amallar mavjud emas!';
