<?php
// Sarlavha
$_['heading_title']     = 'Sovg\'a sertifikati mavzusi';

// Matn
$_['text_success']      = 'Sovg\'a sertifikati mavzusi o\'zgartirildi!';
$_['text_list']         = 'Mavzular ro\'yxati';
$_['text_add']          = 'Qo\'shish';
$_['text_edit']         = 'Tahrirlash';

// Ustun
$_['column_name']       = 'Mavzuni nomi';
$_['column_action']     = 'Harakat';

// Kiritish
$_['entry_name']        = 'Mavzuni nomi';
$_['entry_description'] = 'Mavzuni tavsifi';
$_['entry_image']       = 'Rasm';

// Xatolik
$_['error_permission']  = 'Sizda sertifikat mavzularini o\'zgartirish uchun ruxsat yo\'q!';
$_['error_name']        = 'Nomi 3 dan 32 gacha belgidan iborat bo\'lishi kerak!';
$_['error_image']       = 'Rasm majburiy!';
$_['error_voucher']     = 'Bu mavzu %s sertifikatga tayinlanganligi uchun o\'chirib bo\'lmaydi!';
