<?php
// Sarlavha
$_['heading_title']    = 'Xatoliklar jurnali';

// Matn
$_['text_success']     = 'Xatoliklar jurnali tozalandi!';
$_['text_list']        = 'Xatoliklar';

// Xatolik
$_['error_permission'] = 'Sizda xatoliklar jurnalini tozalash uchun ruxsat yo\'q!';
$_['error_file']       = 'Diqqat: %s faylini topib bo\'lmadi!';
$_['error_size']       = 'Diqqat: %s xatoliklar jurnali fayli hajmi %s ga teng!';
$_['error_empty']      = 'Diqqat: %s xatoliklar jurnali fayli bo\'sh!';
