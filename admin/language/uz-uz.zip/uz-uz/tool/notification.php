<?php
// Sarlavha
$_['heading_title']    = 'Bildirishnomalar';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']        = 'Bildirishnomalar ro\'yxati';

// Ustun
$_['column_message']   = 'Xabar';
$_['column_action']    = 'Harakat';

// Xatolik
$_['error_permission'] = 'Sizda ushbu kengaytmani boshqarish uchun ruxsat yo\'q!';
