<?php
// Text
$_['text_subject']             = '%s - Obuna';
$_['text_subscription_id']     = 'Obuna raqami';
$_['text_date_added']          = 'Obuna qo\'shilgan sana:';
$_['text_subscription_status'] = 'Sizning obunangizga quyidagi holat belgilangan:';
$_['text_comment']             = 'Obunangizga quyidagi izohlarni qo\'yganlar:';
$_['text_payment_method']      = 'To\'lov usuli';
$_['text_payment_code']        = 'To\'lov kodi';
$_['text_footer']              = "Agar savolingiz bo'lsa, iltimos, bu elektron maktubga javob bering.";
