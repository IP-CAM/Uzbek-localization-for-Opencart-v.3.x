<?php
// Matn
$_['text_subject'] = '%s - Sizning hamkorlik hisobingiz rad etildi!';
$_['text_welcome'] = 'Xush kelibsiz va %s ga ro‘yxatdan o‘tganingiz uchun rahmat!';
$_['text_denied']  = 'Afsuski, so‘rovingiz rad etildi. Batafsil ma’lumotlar uchun siz do‘kon egasi bilan bog‘lanishingiz mumkin:';
$_['text_thanks']  = 'Rahmat,';
