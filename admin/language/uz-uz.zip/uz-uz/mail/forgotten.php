<?php
// Matn
$_['text_subject']  = '%s - Parolni o\'zgartirish so\'rovi';
$_['text_greeting'] = '%s Administratsiya paneli uchun yangi parol.';
$_['text_change']   = 'Parolni o\'zgartirish uchun quyidagi havolani bosing';
$_['text_ip']       = 'Bu IP dan so\'rov bajarildi: %s';
