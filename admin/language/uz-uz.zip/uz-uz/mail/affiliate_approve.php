<?php
// Matn
$_['text_subject']  = '%s - Sizning hamkorlik hisobingiz faollashtirildi!';
$_['text_welcome']  = '%s ga ro‘yxatdan o‘tganingiz uchun xush kelibsiz va minnatdorchilik bildiramiz!';
$_['text_login']    = 'Sizning hisobingiz yaratildi va siz Elektron pochta va parolingiz orqali kirishingiz mumkin, saytga tashrif buyuring:';
$_['text_service'] = 'Kirganingizdan so‘ng, siz hamkorlik havolasini olishingiz mumkin bo‘ladi.';
$_['text_thanks']   = 'Rahmat,';
