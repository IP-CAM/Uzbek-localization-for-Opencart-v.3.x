<?php
// Matn
$_['text_subject']    = '%s - Sizning akkauntingiz rad etildi!';
$_['text_welcome']    = 'Xush kelibsiz va %s ro\'yxatdan o\'tganingiz uchun rahmat!';
$_['text_denied']     = 'Afsuski, so\'rovni rad etildi. Batafsil ma\'lumot uchun siz do\'kon egasi bilan bog\'lanishingiz mumkin:';
$_['text_thanks']     = 'Rahmat,';

// Tugma
$_['button_contact']  = 'Biz bilan bog\'lanish';
