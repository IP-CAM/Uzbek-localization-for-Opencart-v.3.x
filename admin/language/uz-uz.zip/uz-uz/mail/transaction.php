<?php
// Text
$_['text_subject']  = '%s - Sherik mukofoti.';
$_['text_received'] = 'Siz %s kredit olishingiz mumkin!';
$_['text_total']    = 'Sizning umumiy sherik mukofotlaringiz miqdori %s.';
$_['text_credit']   = 'Sizning kredit balansingiz do\'kon ichidagi haridlaringiz uchun kredit hisobidan yechilishi mumkin.';
