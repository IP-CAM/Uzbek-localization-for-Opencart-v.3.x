<?php
// Текст
$_['text_subject']   = '%s - GDPR so‘rovi tasdiqlandi!';
$_['text_request']   = 'Hisobni o‘chirish so’rovi';
$_['text_hello']     = 'Salom <strong>%s</strong>,';
$_['text_user']      = 'Foydalanuvchi';
$_['text_gdpr']      = 'Sizning GDPR hisobni o‘chirish so‘rovingiz tasdiqlandi va unni bajarganlik <strong>%s kun</strong> qoldi.';
$_['text_q']         = 'Savol: Nega biz ma’lumotlaringizni hozirroq o‘chirmaymiz?';
$_['text_a']         = 'Javob: Hisobni o‘chirish so‘rovlari <strong>%s kun</strong> ichida ishlab chiqiladi, shundan keyin qaytarib olishlar, qaytarib berishlar yoki g‘ayratkorliklarni aniqlash mumkin bo‘lishi uchun.';
$_['text_delete']    = 'Sizga elektron xabar keladi va hisobni o‘chirildi deb xabar qiladi.';
$_['text_thanks']    = 'Rahmat,';