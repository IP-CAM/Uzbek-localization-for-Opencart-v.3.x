<?php
// Matn
$_['text_subject'] = 'Xavfsizlik';
$_['text_code']    = 'Ishonchli administrator tekshiruvi jarayonida xavfsizlik kodi kiritishingiz kerak.';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Eng yaxshi salomatliklar bilan';
