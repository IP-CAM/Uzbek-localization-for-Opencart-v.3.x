<?php
// Matn
$_['text_subject'] = '%s - Sizning akkauntingiz faollashtirildi!';
$_['text_welcome'] = 'Xush kelibsiz va %s ro\'yxatdan o\'tganingiz uchun rahmat!';
$_['text_login']   = 'Sizning akkauntingiz yaratildi va siz uni E-mail va parolingizni ishlatib, quyidagi manzil orqali saytga kirishingiz mumkin:';
$_['text_service'] = 'Saytda kirganingizdan so\'ng, buyurtmalar tarixini ko\'rish, hisob-fakturani chop etish, o\'zingizning hisobingiz ma\'lumotlarini o\'zgartirish va boshqalar kabi qo\'shimcha imkoniyatlardan foydalanishingiz mumkin.';
$_['text_thanks']  = 'Rahmat,';

// Tugma
$_['button_login'] = 'Kirish';
