<?php
// Text
$_['text_subject']   = '%s - GDPR so‘rovi rad etildi!';
$_['text_export']    = 'Ma’lumotlar eksportini so‘rovi';
$_['text_remove']    = 'Hisobni o‘chirish so‘rovi';
$_['text_hello']     = 'Salom <strong>%s</strong>,';
$_['text_user']      = 'Foydalanuvchi';
$_['text_contact']   = 'Afsuski, so‘rovingiz rad etildi. Qo‘shimcha ma’lumot uchun siz do‘kon bilan quyidagi orqali bog‘lanishingiz mumkin:';
$_['text_thanks']    = 'Rahmat,';

// Button
$_['button_contact'] = 'Biz bilan bog‘lanish';
