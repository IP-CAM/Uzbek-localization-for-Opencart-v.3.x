<?php
// Text
$_['text_subject']  = '%s - Bonus ballar';
$_['text_received'] = 'Siz %s bonus ballar oldingiz!';
$_['text_total']    = 'Sizda jami bonus ballar %s ta.';
