<?php
// Text
$_['text_subject']       = '%s - %s qaytishi yangilandi';
$_['text_return_id']     = 'Qaytish raqami';
$_['text_date_added']    = 'Qaytish sanasi';
$_['text_return_status'] = 'Sizning qaytishingizning joriy holati';
$_['text_comment']       = 'Sizning qaytishingizga izohlari';
$_['text_footer']        = 'Agar sizda savollar bo‘lsa, iltimos, ushbu xabarga javob bering.';
