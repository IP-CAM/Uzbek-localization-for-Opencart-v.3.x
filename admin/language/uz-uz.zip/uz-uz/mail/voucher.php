<?php
// Text
$_['text_success']  = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_subject']  = 'Sizga %s dan Bonus Cheki yuborildi';
$_['text_greeting'] = 'Tabriklaymiz, Siz %s dan Bonus Cheki oldingiz';
$_['text_from']     = 'Sizga Bonus Cheki %s dan';
$_['text_message']  = 'Xabar bilan birgalikda';
$_['text_redeem']   = 'Ushbu Bonus Chekidan foydalangan holda, iltimos, quyidagi havolaga o\'ting va Sizga yoqadigan mahsulotlarni buyurtma bering. Buyurtma berishni boshlashdan oldin, sotib olish sahifasida Bonus Chek kodi kiriting.';
$_['text_footer']   = 'Agar savol bo\'lsa, iltimos, ushbu xabarga javob bering.';
$_['text_sent']     = 'Bonus Cheki e-mailga yuborildi!';
