<?php
// Matn
$_['text_subject'] = 'Himoya kodi tiklash urinishlari';
$_['text_reset']   = 'Kechirasiz, kimsa xavfsizlik kodi 3 marta yoki undan ortiq noto‘g‘ri kirityapti.';
$_['text_link']    = 'Hisobingizning xavfsizlikni tiklash uchun quyidagi havolaga bosing:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Eng yaxshi salomatliklar bilan';
