<?php
// Text
$_['text_subject']   = '%s - GDPR so‘rovi bajarildi!';
$_['text_request']   = 'Hisobni o‘chirish so’rovi';
$_['text_hello']     = 'Salom <strong>%s</strong>,';
$_['text_user']      = 'Foydalanuvchi';
$_['text_delete']    = 'Ma’lumotlaringizni o‘chirish so‘rovingiz amalga oshirildi.';
$_['text_contact']   = 'Qo‘shimcha ma’lumot uchun bizning do‘kon egasiga quyidagi havola orqali murojaat qilishingiz mumkin:';
$_['text_thanks']    = 'Rahmat,';

// Button
$_['button_contact'] = 'Biz bilan bog‘lanish';
