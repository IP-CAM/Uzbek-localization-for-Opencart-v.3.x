<?php
// Text
$_['text_subject']    = '%s - GDPR eksport so‘rovi yakunlandi!';
$_['text_request']    = 'Shaxsiy ma’lumotlar eksporti';
$_['text_hello']      = 'Salom <strong>%s</strong>,';
$_['text_user']       = 'Foydalanuvchi';
$_['text_gdpr']       = 'Sizning GDPR so‘rovingiz yakunlandi. Quyidagi, GDPR bo‘yicha ma’lumotlaringizni topasiz.';
$_['text_account']    = 'Hisob';
$_['text_customer']   = 'Shaxsiy ma’lumotlar';
$_['text_address']    = 'Manzil';
$_['text_addresses']  = 'Manzillar';
$_['text_name']       = 'Mijoz ismi';
$_['text_recipient']  = 'Qabul qiluvchi';
$_['text_email']      = 'E-mail';
$_['text_telephone']  = 'Telefon';
$_['text_company']    = 'Kompaniya';
$_['text_address_1']  = 'Manzil 1';
$_['text_address_2']  = 'Manzil 2';
$_['text_postcode']   = 'Pochta indeksi';
$_['text_city']       = 'Shahar';
$_['text_country']    = 'Mamlakat';
$_['text_zone']       = 'Viloyat';
$_['text_history']    = 'Tizimga kirish tarixi';
$_['text_ip']         = 'IP';
$_['text_date_added'] = 'Sanasi';
$_['text_thanks']     = 'Rahmat,';
