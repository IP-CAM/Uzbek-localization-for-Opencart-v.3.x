<?php
// Sarlavha
$_['heading_title']         = 'Statistika';

// Matn
$_['text_success']          = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']             = 'Ro\'yxat';
$_['text_order_sale']       = 'Buyurtmalar';
$_['text_order_processing'] = 'Bajarilmoqda bo\'lgan buyurtmalar';
$_['text_order_complete']   = 'Buyurtma tugallanganlar';
$_['text_order_other']      = 'Qolgan buyurtmalar';
$_['text_returns']          = 'Qaytarishlar';
$_['text_customer']         = 'Tasdiqlanishni kutuvchi mijozlar';
$_['text_affiliate']        = 'Tasdiqlanishni kutuvchi partnyorlar';
$_['text_product']          = 'Mavjud emas mahsulotlar';
$_['text_review']           = 'Moderatsiya kutuvchasi uchun reytinglar';

// Ustun
$_['column_name']           = 'Nomi';
$_['column_value']          = 'Qiymati';
$_['column_action']         = 'Harakatlar';

// Xatolik
$_['error_permission']      = 'Sizda statistika boshqarish huquqi yo\'q!';
