<?php
// Sarlavha
$_['heading_title']     = 'Onlayn hisobot';

// Matn
$_['text_extension']    = 'Kengaytirishlar';
$_['text_success']      = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_list']         = 'Online mijozlar ro\'yxati';
$_['text_filter']       = 'Filter';
$_['text_guest']        = 'Mehmon';

// Ustun
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Mijoz';
$_['column_url']        = 'So\'nggi ko\'rigan sahifa';
$_['column_referer']    = 'Qayerdan kelgan';
$_['column_date_added'] = 'So\'nggi bosqich';
$_['column_action']     = 'Amal';

// Kiritish
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Mijoz';

// Xatolik
$_['error_permission']  = 'Diqqat: Sizda hisobotni boshqarish uchun ruxsat yo\'q!';
