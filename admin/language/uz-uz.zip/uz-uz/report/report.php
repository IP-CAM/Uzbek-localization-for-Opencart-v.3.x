<?php
// Sarlavha
$_['heading_title'] = 'Hisobotlar';

// Matn
$_['text_success']  = 'Sozlamalar muvaffaqiyatli o\'zgartirildi!';
$_['text_type']     = 'Foydalanmoqchi bo\'lgan hisobotni tanlang';
$_['text_filter']   = 'Filter';
