<?php
// Sarlavha
$_['heading_title']    = 'Qaytarish operatsiyalari';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Qaytarish operatsiyalari ro‘yxati';
$_['text_add']         = 'Qo‘shish';
$_['text_edit']        = 'Tahrirlash';

// Ustunlar
$_['column_name']      = 'Qaytarish operatsiyalari ro‘yxati';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_name']       = 'Qaytarish operatsiyasi';

// Xatolik
$_['error_permission'] = 'Sizda qaytarish operatsiyalarini o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']       = 'Qaytarish operatsiyasi nomi 3 dan 64 belgiga bo‘lishi kerak!';
$_['error_return']     = 'Qaytarish operatsiyasi %s mahsulotlarga qo‘shilganligi uchun o‘chirib bo‘linmaydi!';
