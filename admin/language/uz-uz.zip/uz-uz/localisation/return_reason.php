<?php
// Sarlavha
$_['heading_title']    = 'Qaytarish sababi';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Qaytarish sabablari ro‘yxati';
$_['text_add']         = 'Qo‘shish';
$_['text_edit']        = 'Tahrirlash';

// Ustunlar
$_['column_name']      = 'Qaytarish sabablari ro‘yxati';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_name']       = 'Qaytarish sababi';

// Xatolik
$_['error_permission'] = 'Sizda qaytarish sabablari ni o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']       = 'Qaytarish sababi nomi 3 dan 128 belgiga bo‘lishi kerak!';
$_['error_return']     = 'Qaytarish sababi %s mahsulotlarga qo‘shilganligi uchun o‘chirib bo‘linmaydi!';
