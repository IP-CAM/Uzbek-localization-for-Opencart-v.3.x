<?php
// Sarlavha
$_['heading_title']    = 'Ombordagi holatlar';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Ombordagi holatlar ro‘yxati';
$_['text_add']         = 'Qo‘shish';
$_['text_edit']        = 'Tahrirlash';

// Ustunlar
$_['column_name']      = 'Ombordagi holat variantlari';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_name']       = 'Ombordagi holat nomi';

// Xatolik
$_['error_permission'] = 'Sizda ombordagi holat variantlarini o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']       = 'Holat nomi 3 dan 32 belgiga bo‘lishi kerak!';
$_['error_product']    = 'Ombordagi holati %s mahsulotlarga solishtirilganligi uchun o‘chirib bo‘linmaydi!';
