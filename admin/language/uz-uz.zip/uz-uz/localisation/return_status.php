<?php
// Sarlavha
$_['heading_title']    = 'Qaytarish holatlari';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Qaytarish holatlari ro‘yxati';
$_['text_add']         = 'Qo‘shish';
$_['text_edit']        = 'Tahrirlash';

// Ustunlar
$_['column_name']      = 'Qaytarish holati';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_name']       = 'Qaytarish holati nomi';

// Xatolik
$_['error_permission'] = 'Sizda qaytarish holatlari ni o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']       = 'Qaytarish holati nomi 3 dan 32 belgiga bo‘lishi kerak!';
$_['error_default']    = 'Qaytarish holati asosiy do‘kon holatiga solishtirilganligi uchun o‘chirib bo‘linmaydi!';
$_['error_return']     = 'Qaytarish holati %s qaytaramlarga solishtirilganligi uchun o‘chirib bo‘linmaydi!';
