<?php
// Sarlavha
$_['heading_title']      = 'Obuna holatlari';

// Matn
$_['text_success']       = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']          = 'Obuna holatlari ro‘yxati';
$_['text_add']           = 'Qo‘shish';
$_['text_edit']          = 'Tahrirlash';

// Ustunlar
$_['column_name']        = 'Obuna holati';
$_['column_action']      = 'Harakat';

// Kiritish
$_['entry_name']         = 'Obuna holati nomi';

// Xatolik
$_['error_permission']   = 'Sizda obuna holatlari holatlarini o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']         = 'Obuna holati nomi 3 dan 32 belgiga bo‘lishi kerak!';
$_['error_default']      = 'Obuna holati asosiy do‘kon holati sifatida belgilanganligi uchun o‘chirib bo‘linmaydi!';
$_['error_return']       = 'Obuna holati %s obuna holatlariga tayinlanganligi uchun o‘chirib bo‘linmaydi!';
