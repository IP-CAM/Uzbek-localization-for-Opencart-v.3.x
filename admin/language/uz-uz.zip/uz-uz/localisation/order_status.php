<?php
// Sarlavha
$_['heading_title']    = 'Buyurtmalar holati';

// Matn
$_['text_success']     = 'Sozlamalar muvaffaqiyatli o‘zgartirildi!';
$_['text_list']        = 'Buyurtma holatlari ro‘yxati';
$_['text_add']         = 'Qo‘shish';
$_['text_edit']        = 'Tahrirlash';

// Ustunlar
$_['column_name']      = 'Buyurtmalar holati';
$_['column_action']    = 'Harakat';

// Kiritish
$_['entry_name']       = 'Buyurtmalar holati';

// Xatolik
$_['error_permission'] = 'Sizda buyurtmalar holatlarini o‘zgartirish uchun ruxsat yo‘q!';
$_['error_name']       = 'Buyurtmalar holati nomi 3 dan 32 belgiga bo‘lishi kerak!';
$_['error_default']    = 'Buyurtmalar holati o‘zgarib bo‘lmaydi, chunki u asosiy do‘kon buyurtmalar holati bilan bog‘liq!';
$_['error_download']   = 'Buyurtmalar holati o‘zgarib bo‘lmaydi, chunki u sukunat qilishni sukunat qilish holatiga bog‘liq!';
$_['error_order']      = 'Buyurtmalar holati %s buyurtmalarga qo‘shilganligi uchun o‘chirib bo‘linmaydi!';
