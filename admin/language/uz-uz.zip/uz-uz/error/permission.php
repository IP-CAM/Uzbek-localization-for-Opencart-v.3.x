<?php
// Sarlavha
$_['heading_title']   = 'Kirishni taqiqlangan!';

// Matn
$_['text_permission'] = 'Ushbu sahifaga kirish huquqingiz yo‘q. Agar sizga kerak bo‘lsa, iltimos, administratorga murojaat qiling.';
