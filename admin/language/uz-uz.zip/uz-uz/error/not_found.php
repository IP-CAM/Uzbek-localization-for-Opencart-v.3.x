<?php
// Sarlavha
$_['heading_title']  = 'Sahifa topilmadi!';

// Matn
$_['text_not_found'] = 'Siz so‘rangani topolmadi. Agar muammo qaytarilsa, iltimos, administrator bilan bog‘laning.';
